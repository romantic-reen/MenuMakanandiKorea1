package com.romanticreen.menumakanandikorea1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.bumptech.glide.R;

import java.util.ArrayList;

public abstract class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private RecyclerView rvCategory;
    private ArrayList<KoreanFood> list = new ArrayList<>();
// --Commented out by Inspection START (7/3/2019 1:10 AM):
//    private void setActionBarTitle(String title) {
//        if (getSupportActionBar() != null) {
//        getSupportActionBar().setTitle(title);
//        }
//    }
// --Commented out by Inspection STOP (7/3/2019 1:10 AM)

    private String title = "List Mode";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvCategory = findViewById(R.id.rv_category);
        rvCategory.setHasFixedSize(true);

        Button btnMovewithDataActivity = findViewById(R.id.btn_move_with_data_activity);
        btnMovewithDataActivity.setOnClickListener(this);
    }

       list.addAll(KoreanFoodData.getListData());
       showRecyclerList();
    }

    private void showRecyclerList(){
        rvCategory.setLayoutManager(new LinearLayoutManager(this));
        ListKoreanFoodAdapter listKoreanFoodAdapter = new ListKoreanFoodAdapter(list);
        rvCategory.setAdapter(listKoreanFoodAdapter);
    }

    private void showRecyclerGrid(){
        rvCategory.setLayoutManager(new GridLayoutManager(this, 4));
        GridKoreanFoodAdapter gridKoreanFoodAdapter = new GridKoreanFoodAdapter(list);
        rvCategory.setAdapter(gridKoreanFoodAdapter);

        gridKoreanFoodAdapter.setOnItemClickCallback(new GridKoreanFoodAdapter.OnItemClickCallback() {
        });
    }

    private void showRecyclerCardView() {
        rvCategory.setLayoutManager(new LinearLayoutManager(this));
        CardViewKoreanFoodAdapter cardViewKoreanFoodAdapter = new CardViewKoreanFoodAdapter(list);
        rvCategory.setAdapter(cardViewKoreanFoodAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        setMode(item.getItemId());
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("unused")
    public void setMode(int selectedMode) {
        switch (selectedMode) {
            case R.id.action_list:
                title = "List Mode";
                showRecyclerList();
                break;

            case R.id.action_grid:
                title = "Grid Mode";
                showRecyclerGrid();
                break;

            case R.id.action_cardview:
                title = "Card View Mode";
                showRecyclerCardView();
                break;
         }
                }
        }
    }
}