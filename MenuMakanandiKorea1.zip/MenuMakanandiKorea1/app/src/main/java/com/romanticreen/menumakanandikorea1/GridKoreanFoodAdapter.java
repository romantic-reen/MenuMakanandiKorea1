package com.romanticreen.menumakanandikorea1;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.R;

import java.util.ArrayList;

@SuppressWarnings("ALL")
public class GridKoreanFoodAdapter<listKoreanFood> extends RecyclerView.Adapter<GridKoreanFoodAdapter.GridViewHolder> {
    private final Object KoreanFoodData;

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback) {
        OnItemClickCallback onItemClickCallback1 = onItemClickCallback;
    }
    
    private final ArrayList<listKoreanFood> listKoreanFood;

    public GridKoreanFoodAdapter(ArrayList <KoreanFood> list){
        this.listKoreanFood = (ArrayList<listKoreanFood>) list;
    }

    @NonNull
    @Override
    public GridViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.koreanfood_grid, parent, false);
        return new GridViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GridViewHolder gridViewHolder, int i) {

    }

    @Override
    public int getItemCount(){
        return listKoreanFood.size();
    }

//

    //--Commented out by Inspection START (7/3/2019 1:07 AM):

    //@SuppressLint("CheckResult")

    //@SuppressWarnings("deprecation")
   //@Override
    //public void onBindViewHolder(@NonNull final GridViewHolder holder, int position) {

    ////noinspection deprecation

    //

    //@SuppressWarnings("deprecation") ViewTarget<ImageView, Drawable> imageViewDrawableViewTarget;

    //RequestOptions requestOptions = new RequestOptions();

    //.load(listKoreanFood.get(position).getPhoto()));

    //imageViewDrawableViewTarget = requestOptions.into(holder.imgPhoto);

    //}

    //--Commented out by Inspection STOP (7/3/2019 1:07 AM)

    class GridViewHolder extends RecyclerView.ViewHolder {
        private KoreanFoodData;
        ImageView imgPhoto;

        GridViewHolder(View itemView) {
            super(itemView);
// --Commented out by Inspection START (7/3/2019 1:07 AM):
//            imgPhoto = itemView.findViewById(R.id.img_item_photo);
//        }
//    }
//
//    public static class OnItemClickCallback {
// --Commented out by Inspection STOP (7/3/2019 1:07 AM)
        public void onItemClicked;
        }

    }
}