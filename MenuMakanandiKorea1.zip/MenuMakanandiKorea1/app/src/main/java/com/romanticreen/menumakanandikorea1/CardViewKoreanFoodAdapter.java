package com.romanticreen.menumakanandikorea1;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintSet;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.R;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

import static android.support.v4.content.ContextCompat.startActivity;

public class CardViewKoreanFoodAdapter extends RecyclerView.Adapter<CardViewKoreanFoodAdapter.CardViewViewHolder> {
private ArrayList<KoreanFood> listKoreanFood;

    public CardViewKoreanFoodAdapter(ArrayList<KoreanFood> list) {
        this.listKoreanFood = list;
    }

    @NonNull
    @Override
    public CardViewViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ConstraintSet.Constraint R;
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.koreanfood_cardview, parent, false);
        return new CardViewViewHolder(view);
    }

    @Override
    public int getItemCount() {
        return listKoreanFood.size();
    }

    @Override
    public void onBindViewHolder(@NonNull final CardViewViewHolder holder, int position) {

        KoreanFood koreanFood = listKoreanFood.get(position);

        Glide.with(holder.itemView.getContext())
                .load(koreanFood.getPhoto())
                .apply(new RequestOptions().override(400, 600))
                .into(holder.imgPhoto);

        holder.tvName.setText(koreanFood.getName());
        holder.tvExplanation.setText(koreanFood.getExplanation());

        holder.btnFavourite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.btn_move_with_data_activity:
                        Intent moveIntent = new Intent(MainActivity.this, MoveWithDataActivity.class);
                        startActivity(moveIntent);
                        break;
                    case R.id.btn_move_with_data_activity:
                        Intent moveWithDataIntent = new Intent(MainActivity.this, MoveWithDataActivity.class);
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_NAME, "Kimchi");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_IMAGE, "https://makananoleholeh.com/wp-content/uploads/2017/05/Kimchi-Makanan-Khas-Korea.jpg");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_NAME, "Samgyeopsal");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_IMAGE, "https://makananoleholeh.com/wp-content/uploads/2017/05/Samgyeopsal-Khas-Korea.jpg");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_NAME, "Bibimbap");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_IMAGE, "https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/Dolsot-bibimbap.jpg/1280px-Dolsot-bibimbap.jpg");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_NAME, "Bulgogi");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_IMAGE, "https://makananoleholeh.com/wp-content/uploads/2017/05/Bulgogi-Khas-Korea.jpg");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_NAME, "Haejangguk");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_IMAGE, "https://makananoleholeh.com/wp-content/uploads/2017/05/Haejangguk-Khas-Korea.jpg");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_NAME, "Nakji Bokkeum");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_IMAGE, "https://makananoleholeh.com/wp-content/uploads/2017/05/Nakji-Bokkeum-Khas-Korea.jpg");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_NAME, "Sup Seolleongtang");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_IMAGE, "https://makananoleholeh.com/wp-content/uploads/2017/05/Seolleongtang-Khas-Korea.jpg");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_NAME, "Jeongol");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_IMAGE, "https://makananoleholeh.com/wp-content/uploads/2017/05/Jeongol-Khas-Korea.jpg");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_NAME, "Jjampong");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_IMAGE, "https://makananoleholeh.com/wp-content/uploads/2017/05/Jjampong-Khas-Korea.jpg");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_NAME, "Tteokbokki");
                        moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_IMAGE, "https://makananoleholeh.com/wp-content/uploads/2017/05/Tteokbokki-Khas-Korea.jpg");
                        startActivity(moveWithDataIntent);
                        break;
                }
            }
        }
    }

    private void startActivity(Intent moveWithDataIntent) {
    }
}
        holder.btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
    }

    class CardViewViewHolder extends RecyclerView.ViewHolder {
        ImageView imgPhoto;
        TextView tvName, tvExplanation;
        Button btnFavourite, btnShare;

        CardViewViewHolder(View itemView) {
                super(itemView);
                imgPhoto = itemView.findViewById(R.id.img_item_photo);
                tvName = itemView.findViewById(R.id.tv_item_name);
                tvExplanation = itemView.findViewById(R.id.tv_item_explanation);
                btnFavourite = itemView.findViewById(R.id.btn_set_favourite);
                btnShare = itemView.findViewById(R.id.btn_set_share);
                    }
                }